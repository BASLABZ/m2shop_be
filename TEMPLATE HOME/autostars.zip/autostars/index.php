<?php 
	header('location:template.php');
?>


